//
//  add.cpp
//  Tutorial_5
//
//  Created by Alexander Lin on 12/21/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//

#include <stdio.h>
#include <iostream>
int add(int x, int y)
{
    return x + y;
}
