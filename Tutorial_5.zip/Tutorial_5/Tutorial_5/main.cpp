//
//  main.cpp
//  Tutorial_5
//
//  Created by Alexander Lin on 12/21/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//

#include <iostream>
/*
*  to use functions from other files inside a project, one must declare a
*  prototype of the function to use it. 
*/

int add(int x,int y);
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << add(3,5) << std::endl;
    return 0;
}
