//
//  main.cpp
//  Tutorial_9
//
//  Created by Alexander Lin on 12/25/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    int a = 5; // copy initialization
    int b(5);  // direct initialization
    char ch(97);
    std::cout << ch << std::endl;
    return 0;
}
