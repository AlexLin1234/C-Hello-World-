//
//  main.cpp
//  Hello_World
//
//  Created by Alexander Lin on 12/18/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//


#include <iostream>

int main()
{
    std::cout << "Hello world!" << std::endl;
    return 0;
    
}
