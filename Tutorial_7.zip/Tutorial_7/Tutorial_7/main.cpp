//
//  main.cpp
//  Tutorial_7
//
//  Created by Alexander Lin on 12/23/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//

#include <iostream>
#include "function.hpp"
int main() {
#define MACRO
    //does not work because define is out of scope of function
    //but now you know how to use define and ifdef
    function();
    return 0;
}
