//
//  function.hpp
//  Tutorial_7
//
//  Created by Alexander Lin on 12/24/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//

#ifndef function_hpp
#define function_hpp

#include <stdio.h>
void function();
#endif /* function_hpp */
