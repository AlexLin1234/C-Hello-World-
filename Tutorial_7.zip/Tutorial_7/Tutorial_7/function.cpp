//
//  function.cpp
//  Tutorial_7
//
//  Created by Alexander Lin on 12/24/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//
#include <iostream>
#include "function.hpp"
void function(){
#ifdef MACRO
    std::cout << "is defined" << std::endl;
#endif
#ifndef MACRO
    std::cout << "is not defined" << std::endl;
#endif
}
