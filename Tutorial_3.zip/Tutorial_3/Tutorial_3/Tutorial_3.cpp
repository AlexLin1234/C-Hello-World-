//
//  main.cpp
//  Tutorial_3
//
//  Created by Alexander Lin on 12/20/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//

#include <iostream>
//to initialize a function, one must specify the type and the arguments of the function
//functions cannot be declared inside other functions(cannot be nested)
int GetNum(){
    std::cout << "Enter a Number" << std::endl;
    int a;
    std::cin >> a;
    return a;
}
void printnum_sum(int a,int b){
    std::cout << "The sum of "<< a <<" + "<< b << " is: " << std::endl;
    std::cout << a + b << std::endl;
}
int main(int argc, const char * argv[]) {
    int x = GetNum();
    int y = GetNum();
    printnum_sum(x, y);
    return 0;
}
