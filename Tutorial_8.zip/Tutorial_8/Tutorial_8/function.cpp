//
//  function.cpp
//  Tutorial_8
//
//  Created by Alexander Lin on 12/25/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//

#include "function.hpp"
