//
//  function2.hpp
//  Tutorial_8
//
//  Created by Alexander Lin on 12/25/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//

#pragma once //serves same purpose as header guards, but some compilers may not compile since this is not a c++ official code

#include <stdio.h>

 /* function2_hpp */
