//
//  function.hpp
//  Tutorial_8
//
//  Created by Alexander Lin on 12/25/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//

#ifndef function_hpp   //add this to avoid any errors from other header files defining function_hpp
#define function_hpp

#include <stdio.h>

#endif /* function_hpp */
