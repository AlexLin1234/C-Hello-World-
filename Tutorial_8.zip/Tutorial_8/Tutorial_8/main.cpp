//
//  main.cpp
//  Tutorial_8
//
//  Created by Alexander Lin on 12/24/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
