//
//  main.cpp
//  Tutorial_2
//
//  Created by Alexander Lin on 12/19/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    //A Demonstration of the std::cout, std::cin, and std::endl functions
    std::cout << "Enter a number: "; // ask user for a number
    int x; // no need to initialize x since we're going to overwrite that value on the very next line
    std::cin >> x; // read number from console and store it in x
    
    std::cout << "You entered " << x << std::endl;
    return 0;

}
//std::cout outputs something
//std::endl is a line break
//std::cin is an input function and uses >> instead of <<

