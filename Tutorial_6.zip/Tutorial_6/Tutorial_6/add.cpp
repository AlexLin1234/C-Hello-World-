//
//  add.cpp
//  Tutorial_6
//
//  Created by Alexander Lin on 12/21/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//

#include "add.hpp"
#include <math.h>
int add(int x,int y)
{
    return x+y;
}
