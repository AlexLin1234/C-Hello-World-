//
//  main.cpp
//  Tutorial_6
//
//  Created by Alexander Lin on 12/21/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//

#include <iostream>
#include "add.hpp"
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << add(2,4)<<std::endl;
    return 0;
}
