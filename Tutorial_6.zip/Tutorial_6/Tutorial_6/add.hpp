//
//  add.hpp
//  Tutorial_6
//
//  Created by Alexander Lin on 12/21/16.
//  Copyright © 2016 Alexander Lin. All rights reserved.
//
// This is start of the header guard.  ADD_H can be any unique name.  By convention, we use the name of the header file.
#ifndef add_hpp
#define add_hpp

#include <stdio.h>

// This is the content of the .h file, which is where the declarations go
int add(int x, int y); // function prototype for add.h -- don't forget the semicolon!

// This is the end of the header guard
#endif
